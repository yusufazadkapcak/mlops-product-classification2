"""Inference API module."""

# Inference API is available via src.inference.api
